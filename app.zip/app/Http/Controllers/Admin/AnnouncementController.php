<?php

namespace App\Http\Controllers\Admin;

use App\Enums\AnnouncementCategory;
use App\Http\Controllers\Controller;
use App\Models\Announcement;
use App\Models\Unit;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AnnouncementController extends Controller
{
    public function index(): View
    {
        $admin = auth()->user();

        $announcements = Announcement::with(['createdBy', 'unit'])
            ->when(! $admin->isAdminPusat(), function ($query) use ($admin): void {
                $query->where('unit_id', $admin->unit_id);
            })
            ->latest()
            ->paginate(20);
        $units = $admin->isAdminPusat()
            ? Unit::orderBy('name')->get()
            : Unit::whereKey($admin->unit_id)->get();

        return view('admin.pengumuman.index', compact('announcements', 'units'));
    }

    public function store(Request $request): RedirectResponse
    {
        $admin = $request->user();

        $validated = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'content' => ['required', 'string'],
            'category' => ['required', Rule::in([
                AnnouncementCategory::Umum->value,
                AnnouncementCategory::Penggajian->value,
                AnnouncementCategory::Absensi->value,
                AnnouncementCategory::Kegiatan->value,
            ])],
            'is_global' => ['nullable', 'boolean'],
            'unit_id' => [
                Rule::requiredIf(! $request->boolean('is_global')),
                'nullable',
                'exists:units,id',
            ],
        ]);

        $isGlobal = $admin->isAdminPusat() ? $request->boolean('is_global') : false;
        $unitId = $admin->isAdminPusat()
            ? ($isGlobal ? null : $validated['unit_id'])
            : $admin->unit_id;

        Announcement::create([
            'unit_id' => $unitId,
            'created_by' => $admin->id,
            'title' => $validated['title'],
            'content' => $validated['content'],
            'category' => $validated['category'],
            'is_global' => $isGlobal,
        ]);

        session()->flash('success', 'Pengumuman berhasil ditambahkan.');

        return back();
    }

    public function destroy(Announcement $announcement): RedirectResponse
    {
        $admin = auth()->user();

        if (! $admin->isAdminPusat()) {
            abort_if((int) $announcement->unit_id !== (int) $admin->unit_id, 403);
        }

        $announcement->delete();

        session()->flash('success', 'Pengumuman berhasil dihapus.');

        return back();
    }
}
