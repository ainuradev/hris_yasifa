<?php

namespace App\Http\Controllers\Admin;

use App\Enums\EmployeeType;
use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Models\SalaryRate;
use App\Models\SalaryRateHistory;
use App\Models\Unit;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class EmployeeController extends Controller
{
    public function index(Request $request): View
    {
        $admin = $request->user();

        $stats = [
            'total_aktif' => Employee::visibleToAdmin($admin)->where('status', 'aktif')->count(),
            'total_guru' => Employee::visibleToAdmin($admin)->where('type', EmployeeType::Guru->value)->count(),
            'total_non_guru' => Employee::visibleToAdmin($admin)->where('type', EmployeeType::NonGuru->value)->count(),
            'kontrak_habis_bulan_ini' => Employee::visibleToAdmin($admin)->whereNotNull('contract_end_date')
                ->whereMonth('contract_end_date', now()->month)
                ->whereYear('contract_end_date', now()->year)
                ->count(),
        ];

        return view('admin.karyawan.index', compact('stats'));
    }

    public function create(Request $request): View
    {
        abort_unless($request->user()->isAdminPusat(), 403);

        $units = Unit::orderBy('name')->get();
        $salaryRates = SalaryRate::orderBy('jabatan')
            ->get()
            ->groupBy(fn (SalaryRate $salaryRate) => $salaryRate->type->value);

        return view('admin.karyawan.create', compact('units', 'salaryRates'));
    }

    public function store(Request $request): RedirectResponse
    {
        abort_unless($request->user()->isAdminPusat(), 403);

        $validated = $request->validate([
            'unit_id' => ['required', 'exists:units,id'],
            'name' => ['required', 'string', 'max:255'],
            'nik' => ['required', 'string', 'max:255', 'unique:employees,nik'],
            'email' => ['required', 'email', 'max:255', 'unique:employees,email'],
            'date_of_birth' => ['required', 'date'],
            'type' => ['required', Rule::in([EmployeeType::Guru->value, EmployeeType::NonGuru->value])],
            'role' => ['required', Rule::in(['admin_pusat', 'admin_unit', 'karyawan'])],
            'status' => ['required', Rule::in(['aktif', 'nonaktif'])],
            'contract_end_date' => ['nullable', 'date'],
            'jabatan' => ['required', 'string', 'max:255'],
            'salary_rate_id' => ['required', 'exists:salary_rates,id'],
        ]);

        $defaultPassword = $this->defaultPasswordForRole($validated['date_of_birth'], $validated['role']);

        DB::transaction(function () use ($validated, $defaultPassword): void {
            $employee = new Employee();
            $employee->fill(collect($validated)->except(['jabatan', 'salary_rate_id'])->all());
            $employee->password = Hash::make($defaultPassword);
            $employee->must_change_password = true;
            $employee->save();

            if ($validated['type'] === EmployeeType::Guru->value) {
                $employee->teacherDetail()->create([
                    'salary_rate_id' => $validated['salary_rate_id'],
                    'jabatan' => $validated['jabatan'],
                ]);
            } else {
                $employee->nonTeacherDetail()->create([
                    'salary_rate_id' => $validated['salary_rate_id'],
                    'jabatan' => $validated['jabatan'],
                ]);
            }
        });

        $defaultPasswordMessage = in_array($validated['role'], ['admin_pusat', 'admin_unit'], true)
            ? 'Password default admin adalah admin123'
            : 'Password default menggunakan tanggal lahir format DDMMYYYY';

        session()->flash('success', "Data karyawan berhasil ditambahkan. {$defaultPasswordMessage} dan wajib diganti saat login pertama.");

        return redirect()->route('admin.karyawan.index');
    }

    public function show(Employee $employee): View
    {
        $this->authorizeEmployeeAccess($employee, request()->user());

        $employee->load([
            'unit',
            'teacherDetail.salaryRate',
            'teacherDetail.teacherSubjectUnits.subject',
            'teacherDetail.teacherSubjectUnits.unit',
            'nonTeacherDetail.salaryRate',
            'attendances' => fn ($query) => $query->with('schedule')->latest('checked_in_at')->limit(10),
            'payrolls' => fn ($query) => $query->latest('year')->latest('month')->limit(5),
        ]);

        return view('admin.karyawan.show', compact('employee'));
    }

    public function edit(Employee $employee): View
    {
        abort_unless(request()->user()->isAdminPusat(), 403);
        $employee->load(['teacherDetail', 'nonTeacherDetail']);
        $units = Unit::orderBy('name')->get();
        $salaryRates = SalaryRate::orderBy('jabatan')
            ->get()
            ->groupBy(fn (SalaryRate $salaryRate) => $salaryRate->type->value);

        return view('admin.karyawan.edit', compact('employee', 'units', 'salaryRates'));
    }

    public function update(Request $request, Employee $employee): RedirectResponse
    {
        abort_unless($request->user()->isAdminPusat(), 403);

        $validated = $request->validate([
            'unit_id' => ['required', 'exists:units,id'],
            'name' => ['required', 'string', 'max:255'],
            'nik' => ['required', 'string', 'max:255', Rule::unique('employees', 'nik')->ignore($employee->id)],
            'email' => ['required', 'email', 'max:255', Rule::unique('employees', 'email')->ignore($employee->id)],
            'date_of_birth' => ['nullable', 'date'],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
            'type' => ['required', Rule::in([EmployeeType::Guru->value, EmployeeType::NonGuru->value])],
            'role' => ['required', Rule::in(['admin_pusat', 'admin_unit', 'karyawan'])],
            'status' => ['required', Rule::in(['aktif', 'nonaktif'])],
            'contract_end_date' => ['nullable', 'date'],
            'jabatan' => ['required', 'string', 'max:255'],
            'salary_rate_id' => ['required', 'exists:salary_rates,id'],
        ]);

        DB::transaction(function () use ($validated, $employee): void {
            $previousRateId = $employee->teacherDetail?->salary_rate_id ?? $employee->nonTeacherDetail?->salary_rate_id;

            $employee->fill(collect($validated)->except(['password', 'jabatan', 'salary_rate_id'])->all());

            if (! empty($validated['password'])) {
                $employee->password = Hash::make($validated['password']);
                $employee->must_change_password = true;
            }

            $employee->save();

            if ($validated['type'] === EmployeeType::Guru->value) {
                if ($employee->nonTeacherDetail) {
                    $employee->nonTeacherDetail->delete();
                }

                $detail = $employee->teacherDetail()->updateOrCreate(
                    ['employee_id' => $employee->id],
                    [
                        'salary_rate_id' => $validated['salary_rate_id'],
                        'jabatan' => $validated['jabatan'],
                    ]
                );

                if ($previousRateId && $previousRateId !== $detail->salary_rate_id) {
                    $oldRate = SalaryRate::find($previousRateId);
                    $newRate = SalaryRate::find($detail->salary_rate_id);

                    SalaryRateHistory::create([
                        'salary_rate_id' => $detail->salary_rate_id,
                        'old_rate' => $oldRate?->rate ?? 0,
                        'new_rate' => $newRate?->rate ?? 0,
                        'reason' => 'Perubahan salary rate untuk karyawan: '.$employee->name,
                        'changed_by' => auth()->id(),
                        'changed_at' => now(),
                    ]);
                }
            } else {
                if ($employee->teacherDetail) {
                    $employee->teacherDetail->delete();
                }

                $detail = $employee->nonTeacherDetail()->updateOrCreate(
                    ['employee_id' => $employee->id],
                    [
                        'salary_rate_id' => $validated['salary_rate_id'],
                        'jabatan' => $validated['jabatan'],
                    ]
                );

                if ($previousRateId && $previousRateId !== $detail->salary_rate_id) {
                    $oldRate = SalaryRate::find($previousRateId);
                    $newRate = SalaryRate::find($detail->salary_rate_id);

                    SalaryRateHistory::create([
                        'salary_rate_id' => $detail->salary_rate_id,
                        'old_rate' => $oldRate?->rate ?? 0,
                        'new_rate' => $newRate?->rate ?? 0,
                        'reason' => 'Perubahan salary rate untuk karyawan: '.$employee->name,
                        'changed_by' => auth()->id(),
                        'changed_at' => now(),
                    ]);
                }
            }
        });

        session()->flash('success', ! empty($validated['password'])
            ? 'Data karyawan berhasil diperbarui. Password baru akan wajib diganti saat login berikutnya.'
            : 'Data karyawan berhasil diperbarui.');

        return redirect()->route('admin.karyawan.show', $employee);
    }

    public function destroy(Employee $employee): RedirectResponse
    {
        abort_unless(request()->user()->isAdminPusat(), 403);

        if ($employee->payrolls()->where('status', 'dibayar')->exists()) {
            session()->flash('error', 'Karyawan tidak bisa dihapus karena memiliki payroll yang sudah dibayar.');

            return redirect()->route('admin.karyawan.index');
        }

        $employee->delete();

        session()->flash('success', 'Data karyawan berhasil dihapus.');

        return redirect()->route('admin.karyawan.index');
    }

    private function defaultPasswordForRole(string $dateOfBirth, string $role): string
    {
        if (in_array($role, ['admin_pusat', 'admin_unit'], true)) {
            return 'admin123';
        }

        return Carbon::parse($dateOfBirth)->format('dmY');
    }

    private function authorizeEmployeeAccess(Employee $employee, Employee $admin): void
    {
        if ($admin->isAdminPusat()) {
            return;
        }

        abort_if($employee->unit_id !== $admin->unit_id, 403);
    }
}
