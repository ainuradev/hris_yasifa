<?php

namespace App\Http\Controllers\Admin;

use App\Enums\AttendanceStatus;
use App\Enums\EmployeeRequestStatus;
use App\Enums\LeaveStatus;
use App\Enums\PayrollStatus;
use App\Http\Controllers\Controller;
use App\Models\Announcement;
use App\Models\Attendance;
use App\Models\Employee;
use App\Models\EmployeeRequest;
use App\Models\LeaveRequest;
use App\Models\Payroll;
use App\Models\Unit;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;

class DashboardController extends Controller
{
    public function index(Request $request): View
    {
        $admin = $request->user();
        $today = today();
        $currentMonth = now()->month;
        $currentYear = now()->year;

        $totalEmployees = Employee::visibleToAdmin($admin)->where('status', 'aktif')->count();
        $totalHadirToday = Attendance::where('status', AttendanceStatus::Hadir->value)
            ->whereHas('employee', fn ($query) => $query->visibleToAdmin($admin))
            ->whereHas('schedule', fn ($query) => $query->whereDate('work_date', $today))
            ->count();
        $pendingLeaves = LeaveRequest::where('status', LeaveStatus::Pending->value)
            ->whereHas('employee', fn ($query) => $query->visibleToAdmin($admin))
            ->count();
        $pendingEmployeeRequests = EmployeeRequest::when(! $admin->isAdminPusat(), fn ($query) => $query->where('unit_id', $admin->unit_id))
            ->where('status', EmployeeRequestStatus::Pending->value)
            ->count();
        $paidPayrollTotal = Payroll::where('status', PayrollStatus::Dibayar->value)
            ->whereHas('employee', fn ($query) => $query->visibleToAdmin($admin))
            ->where('month', $currentMonth)
            ->where('year', $currentYear)
            ->sum('net_salary');

        $attendancePerUnit = ($admin->isAdminPusat()
            ? Unit::orderBy('name')->get()
            : Unit::whereKey($admin->unit_id)->get())
            ->map(function (Unit $unit) use ($currentMonth, $currentYear) {
            $totalAttendances = Attendance::whereHas('schedule', function ($query) use ($unit, $currentMonth, $currentYear): void {
                $query->where('unit_id', $unit->id)
                    ->whereMonth('work_date', $currentMonth)
                    ->whereYear('work_date', $currentYear);
            })->count();

            $hadirCount = Attendance::where('status', AttendanceStatus::Hadir->value)
                ->whereHas('schedule', function ($query) use ($unit, $currentMonth, $currentYear): void {
                    $query->where('unit_id', $unit->id)
                        ->whereMonth('work_date', $currentMonth)
                        ->whereYear('work_date', $currentYear);
                })->count();

            return [
                'unit' => $unit,
                'persentase' => $totalAttendances > 0 ? round(($hadirCount / $totalAttendances) * 100, 2) : 0,
                'hadir' => $hadirCount,
                'total' => $totalAttendances,
            ];
        });

        $latestAnnouncements = Announcement::with(['createdBy', 'unit'])
            ->when(! $admin->isAdminPusat(), function ($query) use ($admin): void {
                $query->where(function ($announcementQuery) use ($admin): void {
                    $announcementQuery->where('is_global', true)
                        ->orWhere('unit_id', $admin->unit_id);
                });
            })
            ->latest()
            ->limit(3)
            ->get();

        $cutiPending = LeaveRequest::with('employee')
            ->where('status', LeaveStatus::Pending->value)
            ->whereHas('employee', fn ($query) => $query->visibleToAdmin($admin))
            ->latest('start_date')
            ->limit(5)
            ->get();

        $todayStatusSummary = [
            'hadir' => Attendance::where('status', AttendanceStatus::Hadir->value)
                ->whereHas('employee', fn ($query) => $query->visibleToAdmin($admin))
                ->whereHas('schedule', fn ($query) => $query->whereDate('work_date', $today))
                ->count(),
            'izin' => Attendance::where('status', AttendanceStatus::Izin->value)
                ->whereHas('employee', fn ($query) => $query->visibleToAdmin($admin))
                ->whereHas('schedule', fn ($query) => $query->whereDate('work_date', $today))
                ->count(),
            'sakit' => Attendance::where('status', AttendanceStatus::Sakit->value)
                ->whereHas('employee', fn ($query) => $query->visibleToAdmin($admin))
                ->whereHas('schedule', fn ($query) => $query->whereDate('work_date', $today))
                ->count(),
            'alpa' => Attendance::where('status', AttendanceStatus::Alpa->value)
                ->whereHas('employee', fn ($query) => $query->visibleToAdmin($admin))
                ->whereHas('schedule', fn ($query) => $query->whereDate('work_date', $today))
                ->count(),
        ];

        return view('admin.dashboard', [
            'stats' => [
                'total_karyawan_aktif' => $totalEmployees,
                'hadir_hari_ini' => $totalHadirToday,
                'cuti_pending' => $pendingLeaves,
                'pengajuan_karyawan_pending' => $pendingEmployeeRequests,
                'total_payroll_dibayar_bulan_ini' => $paidPayrollTotal,
                'status_hari_ini' => $todayStatusSummary,
                'kehadiran_per_unit' => $attendancePerUnit,
            ],
            'cutiPending' => $cutiPending,
            'announcements' => $latestAnnouncements,
        ]);
    }
}
