<?php

namespace App\Http\Controllers\Admin;

use App\Enums\AttendanceStatus;
use App\Enums\DayType;
use App\Enums\LeaveStatus;
use App\Enums\LeaveType;
use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\Employee;
use App\Models\LeaveRequest;
use App\Models\Schedule;
use App\Models\TeacherSubjectUnit;
use App\Models\Unit;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\RedirectResponse;

class AbsensiController extends Controller
{
    public function index(Request $request): View
    {
        $admin = $request->user();
        $date = Carbon::parse($request->input('date', today()->toDateString()))->toDateString();
        $selectedUnitId = $admin->isAdminPusat()
            ? ($request->filled('unit_id') ? $request->integer('unit_id') : null)
            : (int) $admin->unit_id;

        $attendances = Attendance::with(['employee.unit', 'schedule.unit', 'teacherSubjectUnit.subject'])
            ->whereHas('employee', function ($query) use ($admin): void {
                $query->visibleToAdmin($admin);
            })
            ->whereHas('schedule', function ($query) use ($date, $selectedUnitId): void {
                $query->whereDate('work_date', $date)
                    ->when($selectedUnitId, fn ($scheduleQuery) => $scheduleQuery->where('unit_id', $selectedUnitId));
            })
            ->latest('checked_in_at')
            ->paginate(20)
            ->withQueryString();

        $summaryQuery = Attendance::query()
            ->whereHas('employee', function ($query) use ($admin): void {
                $query->visibleToAdmin($admin);
            })
            ->whereHas('schedule', function ($query) use ($date, $selectedUnitId): void {
                $query->whereDate('work_date', $date)
                    ->when($selectedUnitId, fn ($scheduleQuery) => $scheduleQuery->where('unit_id', $selectedUnitId));
            });

        $summary = [
            'hadir' => (clone $summaryQuery)->where('status', AttendanceStatus::Hadir->value)->count(),
            'izin' => (clone $summaryQuery)->where('status', AttendanceStatus::Izin->value)->count(),
            'sakit' => (clone $summaryQuery)->where('status', AttendanceStatus::Sakit->value)->count(),
            'alpa' => (clone $summaryQuery)->where('status', AttendanceStatus::Alpa->value)->count(),
        ];
        $summary['persentase_kehadiran'] = array_sum($summary) > 0
            ? round(($summary['hadir'] / array_sum($summary)) * 100, 2)
            : 0;
        $summary['sesi_guru'] = (clone $summaryQuery)->teacherSessions()->count();
        $summary['absensi_harian'] = (clone $summaryQuery)->dailyRecords()->count();

        $units = $admin->isAdminPusat()
            ? Unit::orderBy('name')->get()
            : Unit::whereKey($admin->unit_id)->get();
        $pendingLeaves = LeaveRequest::with('employee')
            ->where('status', LeaveStatus::Pending->value)
            ->whereHas('employee', function ($query) use ($admin): void {
                $query->visibleToAdmin($admin);
            })
            ->latest('start_date')
            ->paginate(20, ['*'], 'leave_page')
            ->withQueryString();

        return view('admin.absensi.index', compact('attendances', 'summary', 'units', 'date', 'pendingLeaves', 'selectedUnitId'));
    }

    public function show(Request $request, Employee $employee): View
    {
        $this->authorizeEmployeeAccess($employee, $request->user());

        $month = (int) $request->input('month', now()->month);
        $year = (int) $request->input('year', now()->year);

        $attendances = Attendance::with(['schedule', 'teacherSubjectUnit.subject', 'teacherSubjectUnit.unit'])
            ->where('employee_id', $employee->id)
            ->whereHas('schedule', function ($query) use ($month, $year): void {
                $query->whereMonth('work_date', $month)
                    ->whereYear('work_date', $year);
            })
            ->latest('checked_in_at')
            ->paginate(20)
            ->withQueryString();

        $baseSummaryQuery = Attendance::query()
            ->where('employee_id', $employee->id)
            ->whereHas('schedule', function ($query) use ($month, $year): void {
                $query->whereMonth('work_date', $month)
                    ->whereYear('work_date', $year);
            });

        $rekap = [
            'hadir' => (clone $baseSummaryQuery)->where('status', AttendanceStatus::Hadir->value)->count(),
            'izin' => (clone $baseSummaryQuery)->where('status', AttendanceStatus::Izin->value)->count(),
            'sakit' => (clone $baseSummaryQuery)->where('status', AttendanceStatus::Sakit->value)->count(),
            'alpa' => (clone $baseSummaryQuery)->where('status', AttendanceStatus::Alpa->value)->count(),
        ];

        $total = array_sum($rekap);
        $rekap['persentase_kehadiran'] = $total > 0 ? round(($rekap['hadir'] / $total) * 100, 2) : 0;
        $rekap['sesi_guru'] = (clone $baseSummaryQuery)->teacherSessions()->count();
        $rekap['absensi_harian'] = (clone $baseSummaryQuery)->dailyRecords()->count();

        return view('admin.absensi.show', compact('employee', 'attendances', 'rekap', 'month', 'year'));
    }

    public function approveLeave(LeaveRequest $leaveRequest): RedirectResponse
    {
        abort_if(request()->user()->isAdminPusat(), 403, 'Hanya Admin Unit yang berhak menyetujui pengajuan cuti.');
        $employee = $leaveRequest->employee()->firstOrFail();
        $this->authorizeEmployeeAccess($employee, request()->user());

        DB::transaction(function () use ($leaveRequest, $employee): void {
            $leaveRequest->update([
                'status' => LeaveStatus::Disetujui->value,
                'reviewed_by' => auth()->id(),
                'reviewed_at' => now(),
            ]);

            $attendanceStatus = $leaveRequest->leave_type === LeaveType::Sakit
                ? AttendanceStatus::Sakit->value
                : AttendanceStatus::Izin->value;

            foreach (CarbonPeriod::create($leaveRequest->start_date, $leaveRequest->end_date) as $date) {
                $schedule = Schedule::query()
                    ->where('unit_id', $employee->unit_id)
                    ->whereDate('work_date', $date->format('Y-m-d'))
                    ->where('day_type', '!=', DayType::Libur->value)
                    ->first();

                if (! $schedule) {
                    continue;
                }

                if ($employee->type->value === 'guru') {
                    $sessions = TeacherSubjectUnit::query()
                        ->whereHas('teacherDetail', fn ($query) => $query->where('employee_id', $employee->id))
                        ->where('unit_id', $employee->unit_id)
                        ->whereRaw('LOWER(day_name) = ?', [strtolower($this->dayNameForDate($date))])
                        ->get();

                    foreach ($sessions as $session) {
                        Attendance::updateOrCreate(
                            [
                                'employee_id' => $employee->id,
                                'schedule_id' => $schedule->id,
                                'teacher_subject_unit_id' => $session->id,
                            ],
                            [
                                'status' => $attendanceStatus,
                                'notes' => $leaveRequest->reason,
                                'checked_in_at' => null,
                                'checked_out_at' => null,
                            ]
                        );
                    }

                    continue;
                }

                Attendance::updateOrCreate(
                    [
                        'employee_id' => $employee->id,
                        'schedule_id' => $schedule->id,
                        'teacher_subject_unit_id' => null,
                    ],
                    [
                        'status' => $attendanceStatus,
                        'notes' => $leaveRequest->reason,
                        'checked_in_at' => null,
                        'checked_out_at' => null,
                    ]
                );
            }
        });

        session()->flash('success', 'Pengajuan cuti berhasil disetujui.');

        return back();
    }

    public function rejectLeave(LeaveRequest $leaveRequest): RedirectResponse
    {
        abort_if(request()->user()->isAdminPusat(), 403, 'Hanya Admin Unit yang berhak menolak pengajuan cuti.');
        $employee = $leaveRequest->employee()->firstOrFail();
        $this->authorizeEmployeeAccess($employee, request()->user());

        $leaveRequest->update([
            'status' => LeaveStatus::Ditolak->value,
            'reviewed_by' => auth()->id(),
            'reviewed_at' => now(),
        ]);

        session()->flash('success', 'Pengajuan cuti berhasil ditolak.');

        return back();
    }

    private function authorizeEmployeeAccess(Employee $employee, Employee $admin): void
    {
        if ($admin->isAdminPusat()) {
            return;
        }

        abort_if($employee->unit_id !== $admin->unit_id, 403);
    }

    private function dayNameForDate(Carbon $date): string
    {
        return match ($date->dayOfWeekIso) {
            1 => 'Senin',
            2 => 'Selasa',
            3 => 'Rabu',
            4 => 'Kamis',
            5 => 'Jumat',
            6 => 'Sabtu',
            default => 'Minggu',
        };
    }
}
