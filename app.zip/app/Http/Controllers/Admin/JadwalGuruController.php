<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Subject;
use App\Models\TeacherDetail;
use App\Models\TeacherSubjectUnit;
use App\Models\Unit;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class JadwalGuruController extends Controller
{
    public function index(Request $request): View
    {
        $admin = $request->user();
        $selectedUnitId = $admin->isAdminPusat()
            ? ($request->filled('unit_id') ? $request->integer('unit_id') : null)
            : (int) $admin->unit_id;

        $teacherDetailsQuery = TeacherDetail::query()
            ->with([
                'employee.unit',
                'salaryRate',
                'teacherSubjectUnits' => function ($query) use ($selectedUnitId): void {
                    $query->with(['subject', 'unit'])
                        ->when($selectedUnitId, fn ($teacherSubjectUnitQuery) => $teacherSubjectUnitQuery->where('unit_id', $selectedUnitId));
                },
            ])
            ->when($selectedUnitId, function (Builder $query) use ($selectedUnitId): void {
                $query->where(function (Builder $innerQuery) use ($selectedUnitId): void {
                    $innerQuery->whereHas('employee', fn (Builder $employeeQuery) => $employeeQuery->where('unit_id', $selectedUnitId))
                        ->orWhereHas('teacherSubjectUnits', fn (Builder $teacherSubjectUnitQuery) => $teacherSubjectUnitQuery->where('unit_id', $selectedUnitId));
                });
            })
            ->when($request->filled('search'), function (Builder $query) use ($request, $selectedUnitId): void {
                $search = $request->string('search')->value();

                $query->where(function (Builder $innerQuery) use ($search, $selectedUnitId): void {
                    $innerQuery->whereHas('employee', function ($employeeQuery) use ($search): void {
                        $employeeQuery->where('name', 'like', "%{$search}%")
                            ->orWhere('nik', 'like', "%{$search}%");
                    })->orWhereHas('teacherSubjectUnits', function (Builder $teacherSubjectUnitQuery) use ($search, $selectedUnitId): void {
                        $teacherSubjectUnitQuery
                            ->when($selectedUnitId, fn (Builder $scopedQuery) => $scopedQuery->where('unit_id', $selectedUnitId))
                            ->whereHas('subject', fn (Builder $subjectQuery) => $subjectQuery->where('name', 'like', "%{$search}%"));
                    });
                });
            })
            ->paginate(20)
            ->withQueryString();

        $teacherDetailsQuery->getCollection()->transform(function (TeacherDetail $teacherDetail): TeacherDetail {
            $teacherDetail->setRelation(
                'teacherSubjectUnits',
                $teacherDetail->teacherSubjectUnits
                    ->sortBy(fn ($item) => sprintf('%s-%s', $item->day_name ?? 'Zzz', $item->start_time?->format('H:i') ?? '99:99'))
                    ->values()
            );

            return $teacherDetail;
        });

        $statsTeacherDetails = TeacherDetail::query()
            ->with([
                'teacherSubjectUnits' => function ($query) use ($selectedUnitId): void {
                    $query->when($selectedUnitId, fn ($teacherSubjectUnitQuery) => $teacherSubjectUnitQuery->where('unit_id', $selectedUnitId));
                },
            ])
            ->when($selectedUnitId, function (Builder $query) use ($selectedUnitId): void {
                $query->where(function (Builder $innerQuery) use ($selectedUnitId): void {
                    $innerQuery->whereHas('employee', fn (Builder $employeeQuery) => $employeeQuery->where('unit_id', $selectedUnitId))
                        ->orWhereHas('teacherSubjectUnits', fn (Builder $teacherSubjectUnitQuery) => $teacherSubjectUnitQuery->where('unit_id', $selectedUnitId));
                });
            })
            ->when($request->filled('search'), function (Builder $query) use ($request, $selectedUnitId): void {
                $search = $request->string('search')->value();

                $query->where(function (Builder $innerQuery) use ($search, $selectedUnitId): void {
                    $innerQuery->whereHas('employee', function ($employeeQuery) use ($search): void {
                        $employeeQuery->where('name', 'like', "%{$search}%")
                            ->orWhere('nik', 'like', "%{$search}%");
                    })->orWhereHas('teacherSubjectUnits', function (Builder $teacherSubjectUnitQuery) use ($search, $selectedUnitId): void {
                        $teacherSubjectUnitQuery
                            ->when($selectedUnitId, fn (Builder $scopedQuery) => $scopedQuery->where('unit_id', $selectedUnitId))
                            ->whereHas('subject', fn (Builder $subjectQuery) => $subjectQuery->where('name', 'like', "%{$search}%"));
                    });
                });
            })
            ->get();

        $units = $admin->isAdminPusat()
            ? Unit::orderBy('name')->get()
            : Unit::whereKey($admin->unit_id)->get();

        $visibleSessions = $statsTeacherDetails
            ->flatMap(fn (TeacherDetail $teacherDetail) => $teacherDetail->teacherSubjectUnits);

        $stats = [
            'total_guru' => $statsTeacherDetails->count(),
            'total_mapel' => $visibleSessions->pluck('subject_id')->filter()->unique()->count(),
            'total_sesi' => $visibleSessions->count(),
            'total_jam' => $visibleSessions->sum('hours_per_week'),
        ];

        $selectedUnit = $selectedUnitId ? $units->firstWhere('id', $selectedUnitId) ?? Unit::find($selectedUnitId) : null;

        return view('admin.jadwal.index', [
            'teacherDetails' => $teacherDetailsQuery,
            'units' => $units,
            'stats' => $stats,
            'selectedUnitId' => $selectedUnitId,
            'selectedUnit' => $selectedUnit,
        ]);
    }

    public function edit(Request $request, TeacherDetail $teacherDetail): View
    {
        $admin = $request->user();
        $this->authorizeTeacherDetailAccess($teacherDetail, $admin);

        $teacherDetail->load([
            'employee.unit',
            'salaryRate',
            'teacherSubjectUnits' => fn ($query) => $query->with(['subject', 'unit'])->orderBy('day_name')->orderBy('start_time'),
        ]);

        $subjects = Subject::orderBy('name')->get();
        $units = $admin->isAdminPusat()
            ? Unit::orderBy('name')->get()
            : Unit::whereKey($admin->unit_id)->get();

        return view('admin.jadwal.edit', compact('teacherDetail', 'subjects', 'units'));
    }

    public function storeSession(Request $request, TeacherDetail $teacherDetail): RedirectResponse
    {
        $admin = $request->user();
        $this->authorizeTeacherDetailAccess($teacherDetail, $admin);

        $validated = $this->validateSession($request, $admin);

        $teacherDetail->teacherSubjectUnits()->create($validated);

        session()->flash('success', 'Sesi mengajar baru berhasil ditambahkan.');

        return redirect()->route('admin.jadwal.edit', $teacherDetail);
    }

    public function updateSession(Request $request, TeacherSubjectUnit $teacherSubjectUnit): RedirectResponse
    {
        $admin = $request->user();
        $teacherSubjectUnit->loadMissing('teacherDetail.employee');
        $this->authorizeTeacherDetailAccess($teacherSubjectUnit->teacherDetail, $admin);

        $validated = $this->validateSession($request, $admin);

        $teacherSubjectUnit->update($validated);

        session()->flash('success', 'Sesi mengajar berhasil diperbarui.');

        return redirect()->route('admin.jadwal.edit', $teacherSubjectUnit->teacherDetail);
    }

    public function destroySession(Request $request, TeacherSubjectUnit $teacherSubjectUnit): RedirectResponse
    {
        $admin = $request->user();
        $teacherSubjectUnit->loadMissing('teacherDetail.employee');
        $this->authorizeTeacherDetailAccess($teacherSubjectUnit->teacherDetail, $admin);

        $teacherDetail = $teacherSubjectUnit->teacherDetail;
        $teacherSubjectUnit->delete();

        session()->flash('success', 'Sesi mengajar berhasil dihapus.');

        return redirect()->route('admin.jadwal.edit', $teacherDetail);
    }

    private function validateSession(Request $request, $admin): array
    {
        $validated = $request->validate([
            'unit_id' => ['required', 'integer', 'exists:units,id'],
            'subject_id' => ['required', 'integer', 'exists:subjects,id'],
            'day_name' => ['required', Rule::in(['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'])],
            'class_name' => ['required', 'string', 'max:255'],
            'start_time' => ['required', 'date_format:H:i'],
            'end_time' => ['required', 'date_format:H:i', 'after:start_time'],
            'hours_per_week' => ['required', 'integer', 'min:1', 'max:40'],
        ]);

        if (! $admin->isAdminPusat()) {
            $validated['unit_id'] = (int) $admin->unit_id;
        }

        return $validated;
    }

    private function authorizeTeacherDetailAccess(TeacherDetail $teacherDetail, $admin): void
    {
        $teacherDetail->loadMissing('employee');

        if ($admin->isAdminPusat()) {
            return;
        }

        abort_if((int) $teacherDetail->employee?->unit_id !== (int) $admin->unit_id, 403);
    }
}
