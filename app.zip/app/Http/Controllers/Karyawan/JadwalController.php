<?php

namespace App\Http\Controllers\Karyawan;

use App\Enums\AttendanceStatus;
use App\Enums\DayType;
use App\Enums\EmployeeType;
use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\Concerns\HandlesTeacherAttendance;
use App\Models\Schedule;
use Carbon\Carbon;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class JadwalController extends Controller
{
    use HandlesTeacherAttendance;

    public function index(): View|RedirectResponse
    {
        $employee = auth()->user();
        $periodStart = now()->startOfMonth();
        $periodEnd = now()->endOfDay();

        if ($employee->type !== EmployeeType::Guru) {
            session()->flash('error', 'Jadwal mengajar hanya tersedia untuk guru.');

            return redirect()->route('karyawan.dashboard');
        }

        $employee->load([
            'teacherDetail.teacherSubjectUnits.subject',
            'teacherDetail.teacherSubjectUnits.unit',
        ]);

        $teacherSubjectUnits = $employee->teacherDetail?->teacherSubjectUnits ?? collect();
        $groupedTeacherSubjectUnits = $teacherSubjectUnits
            ->sortBy(fn ($item) => sprintf('%s-%s', $item->day_name ?? 'Zzz', $item->start_time?->format('H:i') ?? '99:99'))
            ->groupBy(fn ($item) => $item->day_name ?? 'Belum diatur');

        $todayTeacherSubjectUnits = $this->todayTeacherSubjectUnits($employee);

        $weekSchedules = Schedule::where('unit_id', $employee->unit_id)
            ->whereBetween('work_date', [now()->startOfWeek(), now()->endOfWeek()])
            ->orderBy('work_date')
            ->get();

        $todaySchedule = Schedule::query()
            ->where('unit_id', $employee->unit_id)
            ->whereDate('work_date', today())
            ->first();

        $sessionAttendances = $todaySchedule
            ? $this->teacherAttendanceForSchedule($employee, $todaySchedule)
            : collect();
        $activeTeacherSession = ($todaySchedule && $todaySchedule->day_type !== DayType::Libur)
            ? $this->activeTeacherSession($todayTeacherSubjectUnits)
            : null;
        $activeTeacherAttendance = $activeTeacherSession
            ? $sessionAttendances->get($activeTeacherSession->id)
            : null;
        $todayAttendance = $sessionAttendances->sortBy('checked_in_at')->first();
        $checkInWindowStart = $activeTeacherSession?->start_time
            ? Carbon::parse(today()->format('Y-m-d').' '.$activeTeacherSession->start_time->format('H:i:s'))
            : null;
        $checkInWindowEnd = $activeTeacherSession?->end_time
            ? Carbon::parse(today()->format('Y-m-d').' '.$activeTeacherSession->end_time->format('H:i:s'))
            : null;
        $canCheckInFromSchedule = $checkInWindowStart
            && $checkInWindowEnd
            && ! $activeTeacherAttendance
            && now()->between($checkInWindowStart, $checkInWindowEnd);

        $periodAttendances = Attendance::query()
            ->with(['schedule', 'teacherSubjectUnit.subject', 'teacherSubjectUnit.unit'])
            ->where('employee_id', $employee->id)
            ->teacherSessions()
            ->whereHas('schedule', function ($query) use ($periodStart, $periodEnd): void {
                $query->whereBetween('work_date', [$periodStart->toDateString(), $periodEnd->toDateString()]);
            })
            ->get()
            ->sortBy(fn (Attendance $attendance) => sprintf(
                '%s %s',
                $attendance->schedule?->work_date?->format('Y-m-d') ?? '0000-00-00',
                $attendance->teacherSubjectUnit?->start_time?->format('H:i:s') ?? '99:99:99'
            ))
            ->values();

        $attendancePeriodLabel = sprintf(
            '%s - %s',
            $periodStart->translatedFormat('d M Y'),
            $periodEnd->translatedFormat('d M Y')
        );

        return view('karyawan.jadwal.index', compact(
            'groupedTeacherSubjectUnits',
            'weekSchedules',
            'todayTeacherSubjectUnits',
            'sessionAttendances',
            'todaySchedule',
            'todayAttendance',
            'activeTeacherSession',
            'activeTeacherAttendance',
            'checkInWindowStart',
            'checkInWindowEnd',
            'canCheckInFromSchedule',
            'periodAttendances',
            'attendancePeriodLabel',
        ));
    }

    public function storeAttendance(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'teacher_subject_unit_id' => ['required', 'integer', 'exists:teacher_subject_unit,id'],
            'latitude' => ['nullable', 'numeric'],
            'longitude' => ['nullable', 'numeric'],
            'notes' => ['nullable', 'string', 'max:255'],
        ]);

        $employee = auth()->user();

        if ($employee->type !== EmployeeType::Guru) {
            session()->flash('error', 'Fitur hadir dari jadwal hanya tersedia untuk guru.');

            return redirect()->route('karyawan.dashboard');
        }

        $todayTeacherSubjectUnits = $this->todayTeacherSubjectUnits($employee);

        if ($todayTeacherSubjectUnits->isEmpty()) {
            session()->flash('error', 'Tidak ada jadwal mengajar hari ini.');

            return back();
        }

        $todaySchedule = Schedule::query()
            ->where('unit_id', $employee->unit_id)
            ->whereDate('work_date', today())
            ->first();

        if (! $todaySchedule) {
            session()->flash('error', 'Tidak ada schedule unit hari ini.');

            return back();
        }

        if ($todaySchedule->day_type === DayType::Libur) {
            session()->flash('error', 'Hari ini adalah hari libur.');

            return back();
        }

        $teacherSubjectUnit = $todayTeacherSubjectUnits->firstWhere('id', (int) $validated['teacher_subject_unit_id']);

        if (! $teacherSubjectUnit) {
            session()->flash('error', 'Sesi mengajar yang dipilih tidak valid untuk hari ini.');

            return back();
        }

        $existingAttendance = Attendance::query()
            ->where('employee_id', $employee->id)
            ->where('schedule_id', $todaySchedule->id)
            ->where('teacher_subject_unit_id', $teacherSubjectUnit->id)
            ->first();

        if ($existingAttendance) {
            session()->flash('error', 'Absensi untuk sesi ini sudah tercatat.');

            return back();
        }

        $windowStart = Carbon::parse(today()->format('Y-m-d').' '.$teacherSubjectUnit->start_time?->format('H:i:s'));
        $windowEnd = Carbon::parse(today()->format('Y-m-d').' '.$teacherSubjectUnit->end_time?->format('H:i:s'));

        if (! now()->between($windowStart, $windowEnd)) {
            session()->flash('error', 'Tombol hadir sesi ini hanya bisa digunakan saat jam pelajaran berlangsung, yaitu antara '.$windowStart->format('H:i').' - '.$windowEnd->format('H:i').'.');

            return back();
        }

        Attendance::create([
            'employee_id' => $employee->id,
            'schedule_id' => $todaySchedule->id,
            'teacher_subject_unit_id' => $teacherSubjectUnit->id,
            'checked_in_at' => now(),
            'checked_out_at' => null,
            'latitude' => $validated['latitude'] ?? null,
            'longitude' => $validated['longitude'] ?? null,
            'status' => AttendanceStatus::Hadir->value,
            'notes' => $validated['notes'] ?? null,
        ]);

        session()->flash('success', 'Hadir untuk sesi '.$teacherSubjectUnit->subject?->name.' berhasil disimpan.');

        return back();
    }

    private function todayDayName(): string
    {
        return match (now()->dayOfWeekIso) {
            1 => 'Senin',
            2 => 'Selasa',
            3 => 'Rabu',
            4 => 'Kamis',
            5 => 'Jumat',
            6 => 'Sabtu',
            default => 'Minggu',
        };
    }
}
