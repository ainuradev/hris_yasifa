<?php

namespace App\Http\Controllers\Karyawan;

use App\Enums\AttendanceStatus;
use App\Enums\DayType;
use App\Enums\EmployeeType;
use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\Schedule;
use App\Support\AttendanceLocation;
use Carbon\Carbon;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class AbsensiController extends Controller
{
    public function index(): View
    {
        $employee = auth()->user();
        $periodStart = now()->startOfMonth();
        $periodEnd = now()->endOfDay();
        $schedule = Schedule::query()
            ->where('unit_id', $employee->unit_id)
            ->whereDate('work_date', today())
            ->first();

        $attendanceQuery = Attendance::query()
            ->with(['schedule', 'teacherSubjectUnit.subject', 'teacherSubjectUnit.unit'])
            ->where('employee_id', $employee->id)
            ->whereHas('schedule', function ($query) use ($periodStart, $periodEnd): void {
                $query->whereBetween('work_date', [$periodStart->toDateString(), $periodEnd->toDateString()]);
            });

        if ($employee->type === EmployeeType::Guru) {
            $attendanceToday = $schedule
                ? Attendance::where('employee_id', $employee->id)
                    ->where('schedule_id', $schedule->id)
                    ->teacherSessions()
                    ->latest('checked_in_at')
                    ->first()
                : null;

            $attendances = $attendanceQuery
                ->teacherSessions()
                ->orderByDesc('checked_in_at')
                ->paginate(20);
        } else {
            $attendanceToday = $schedule
                ? Attendance::where('employee_id', $employee->id)
                    ->where('schedule_id', $schedule->id)
                    ->dailyRecords()
                    ->first()
                : null;

            $attendances = $attendanceQuery
                ->dailyRecords()
                ->latest('checked_in_at')
                ->paginate(20);
        }

        $attendanceCoordinates = AttendanceLocation::coordinates();
        $attendancePeriodLabel = sprintf(
            '%s - %s',
            $periodStart->translatedFormat('d M Y'),
            $periodEnd->translatedFormat('d M Y')
        );

        return view('karyawan.absensi.index', compact(
            'schedule',
            'attendanceToday',
            'attendances',
            'attendanceCoordinates',
            'attendancePeriodLabel'
        ));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'latitude' => ['nullable', 'numeric'],
            'longitude' => ['nullable', 'numeric'],
            'notes' => ['nullable', 'string', 'max:255'],
        ]);

        $employee = auth()->user();

        $schedule = Schedule::query()
            ->where('unit_id', $employee->unit_id)
            ->whereDate('work_date', today())
            ->first();

        if (! $schedule) {
            session()->flash('error', 'Tidak ada jadwal hari ini.');

            return back();
        }

        if ($schedule->day_type === DayType::Libur) {
            session()->flash('error', 'Hari ini adalah hari libur.');

            return back();
        }

        $now = now();
        $attendance = Attendance::where('employee_id', $employee->id)
            ->where('schedule_id', $schedule->id)
            ->whereNull('teacher_subject_unit_id')
            ->first();

        if ($employee->type === EmployeeType::Guru && ! $attendance) {
            session()->flash('error', 'Untuk guru, absensi hadir dilakukan dari halaman Jadwal Mengajar.');

            return redirect()->route('karyawan.jadwal.index');
        }

        if ($attendance) {
            if (is_null($attendance->checked_out_at)) {
                $attendance->update([
                    'checked_out_at' => $now,
                    'notes' => $validated['notes'] ?? $attendance->notes,
                ]);

                session()->flash('success', 'Absensi pulang berhasil disimpan.');

                return back();
            }

            session()->flash('error', 'Absensi hari ini sudah selesai.');

            return back();
        }

        $checkInStart = Carbon::parse($schedule->work_date->format('Y-m-d').' '.$schedule->check_in_start);
        $checkInEnd = Carbon::parse($schedule->work_date->format('Y-m-d').' '.$schedule->check_in_end);

        if (! $now->between($checkInStart, $checkInEnd)) {
            session()->flash('error', 'Jam absen hanya tersedia antara '.$checkInStart->format('H:i').' - '.$checkInEnd->format('H:i').'.');

            return back();
        }

        $coordinates = AttendanceLocation::coordinates();

        if (! $coordinates) {
            session()->flash('error', 'Lokasi yayasan belum diatur. Silakan hubungi admin.');

            return back();
        }

        if (! isset($validated['latitude'], $validated['longitude'])) {
            session()->flash('error', 'Lokasi Anda wajib tersedia untuk melakukan hadir.');

            return back();
        }

        $distance = AttendanceLocation::distanceInMeters(
            (float) $validated['latitude'],
            (float) $validated['longitude'],
            $coordinates['latitude'],
            $coordinates['longitude']
        );

        if ($distance > AttendanceLocation::radiusMeters()) {
            session()->flash('error', 'Lokasi Anda berada sekitar '.number_format($distance, 0, ',', '.').' meter dari yayasan. Maksimal jarak hadir adalah '.AttendanceLocation::radiusMeters().' meter.');

            return back();
        }

        Attendance::create([
            'employee_id' => $employee->id,
            'schedule_id' => $schedule->id,
            'checked_in_at' => $now,
            'checked_out_at' => null,
            'latitude' => $validated['latitude'] ?? null,
            'longitude' => $validated['longitude'] ?? null,
            'status' => AttendanceStatus::Hadir->value,
            'notes' => $validated['notes'] ?? null,
        ]);

        session()->flash('success', 'Absensi berhasil disimpan.');

        return back();
    }
}
