<?php

namespace App\Models;

use App\Enums\AttendanceStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Schema;

class Attendance extends Model
{
    use HasFactory;

    protected $fillable = [
        'employee_id',
        'schedule_id',
        'teacher_subject_unit_id',
        'checked_in_at',
        'checked_out_at',
        'latitude',
        'longitude',
        'status',
        'notes',
    ];

    protected $casts = [
        'checked_in_at' => 'datetime',
        'checked_out_at' => 'datetime',
        'status' => AttendanceStatus::class,
    ];

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }

    public function schedule(): BelongsTo
    {
        return $this->belongsTo(Schedule::class);
    }

    public function teacherSubjectUnit(): BelongsTo
    {
        return $this->belongsTo(TeacherSubjectUnit::class);
    }

    public function scopeTeacherSessions(Builder $query): Builder
    {
        if (! Schema::hasColumn($this->getTable(), 'teacher_subject_unit_id')) {
            return $query;
        }

        return $query->whereNotNull('teacher_subject_unit_id');
    }

    public function scopeDailyRecords(Builder $query): Builder
    {
        if (! Schema::hasColumn($this->getTable(), 'teacher_subject_unit_id')) {
            return $query;
        }

        return $query->whereNull('teacher_subject_unit_id');
    }
}
