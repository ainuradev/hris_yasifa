<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TeacherSubjectUnit extends Model
{
    use HasFactory;

    protected $table = 'teacher_subject_unit';

    public $timestamps = false;

    protected $fillable = [
        'teacher_detail_id',
        'unit_id',
        'subject_id',
        'day_name',
        'class_name',
        'start_time',
        'end_time',
        'hours_per_week',
    ];

    protected $casts = [
        'start_time' => 'datetime:H:i',
        'end_time' => 'datetime:H:i',
    ];

    public function teacherDetail(): BelongsTo
    {
        return $this->belongsTo(TeacherDetail::class);
    }

    public function unit(): BelongsTo
    {
        return $this->belongsTo(Unit::class);
    }

    public function subject(): BelongsTo
    {
        return $this->belongsTo(Subject::class);
    }
}
