<?php

use App\Http\Controllers\Admin\AbsensiController as AdminAbsensiController;
use App\Http\Controllers\Admin\AnnouncementController as AdminAnnouncementController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\EmployeeController as AdminEmployeeController;
use App\Http\Controllers\Admin\EmployeeRequestController as AdminEmployeeRequestController;
use App\Http\Controllers\Admin\JadwalGuruController as AdminJadwalGuruController;
use App\Http\Controllers\Admin\PenggajianController as AdminPenggajianController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Karyawan\AbsensiController as KaryawanAbsensiController;
use App\Http\Controllers\Karyawan\CutiController as KaryawanCutiController;
use App\Http\Controllers\Karyawan\DashboardController as KaryawanDashboardController;
use App\Http\Controllers\Karyawan\GajiController as KaryawanGajiController;
use App\Http\Controllers\Karyawan\JadwalController as KaryawanJadwalController;
use App\Http\Controllers\Karyawan\PengumumanController as KaryawanPengumumanController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::middleware('guest')->group(function (): void {
    Route::get('/login', [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('/login', [AuthenticatedSessionController::class, 'store'])->name('login.store');
});

Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])
    ->middleware('auth')
    ->name('logout');

Route::prefix('admin')->name('admin.')->middleware(['auth', 'role:admin_pusat,admin_unit'])->group(function (): void {
    Route::get('/profil', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profil', [ProfileController::class, 'update'])->name('profile.update');

    Route::middleware('password.changed')->group(function (): void {
        Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

        Route::resource('subjects', \App\Http\Controllers\Admin\SubjectController::class)->except(['create', 'show', 'edit']);

        Route::get('/karyawan', [AdminEmployeeController::class, 'index'])->name('karyawan.index');
        Route::get('/karyawan/create', [AdminEmployeeController::class, 'create'])->name('karyawan.create');
        Route::post('/karyawan', [AdminEmployeeController::class, 'store'])->name('karyawan.store');
        Route::get('/karyawan/{employee}', [AdminEmployeeController::class, 'show'])->name('karyawan.show');
        Route::get('/karyawan/{employee}/edit', [AdminEmployeeController::class, 'edit'])->name('karyawan.edit');
        Route::put('/karyawan/{employee}', [AdminEmployeeController::class, 'update'])->name('karyawan.update');
        Route::delete('/karyawan/{employee}', [AdminEmployeeController::class, 'destroy'])->name('karyawan.destroy');

        Route::get('/pengajuan-karyawan', [AdminEmployeeRequestController::class, 'index'])->name('employee-requests.index');
        Route::get('/pengajuan-karyawan/create', [AdminEmployeeRequestController::class, 'create'])->name('employee-requests.create');
        Route::post('/pengajuan-karyawan', [AdminEmployeeRequestController::class, 'store'])->name('employee-requests.store');
        Route::patch('/pengajuan-karyawan/{employeeRequest}/approve', [AdminEmployeeRequestController::class, 'approve'])->name('employee-requests.approve');
        Route::patch('/pengajuan-karyawan/{employeeRequest}/reject', [AdminEmployeeRequestController::class, 'reject'])->name('employee-requests.reject');

        Route::get('/jadwal-guru', [AdminJadwalGuruController::class, 'index'])->name('jadwal.index');
        Route::get('/jadwal-guru/{teacherDetail}/edit', [AdminJadwalGuruController::class, 'edit'])->name('jadwal.edit');
        Route::post('/jadwal-guru/{teacherDetail}/sessions', [AdminJadwalGuruController::class, 'storeSession'])->name('jadwal.sessions.store');
        Route::patch('/jadwal-guru/sessions/{teacherSubjectUnit}', [AdminJadwalGuruController::class, 'updateSession'])->name('jadwal.sessions.update');
        Route::delete('/jadwal-guru/sessions/{teacherSubjectUnit}', [AdminJadwalGuruController::class, 'destroySession'])->name('jadwal.sessions.destroy');

        Route::get('/absensi', [AdminAbsensiController::class, 'index'])->name('absensi.index');
        Route::get('/absensi/{employee}', [AdminAbsensiController::class, 'show'])->name('absensi.show');
        Route::patch('/absensi/leave/{leaveRequest}/approve', [AdminAbsensiController::class, 'approveLeave'])->name('absensi.approve');
        Route::patch('/absensi/leave/{leaveRequest}/reject', [AdminAbsensiController::class, 'rejectLeave'])->name('absensi.reject');

        Route::get('/penggajian', [AdminPenggajianController::class, 'index'])->name('penggajian.index');
        Route::get('/penggajian/generate', [AdminPenggajianController::class, 'generateForm'])->name('penggajian.generate.form');
        Route::post('/penggajian/generate', [AdminPenggajianController::class, 'generate'])->name('penggajian.generate.store');
        Route::get('/penggajian/{payroll}', [AdminPenggajianController::class, 'show'])->name('penggajian.show');
        Route::patch('/penggajian/{payroll}/finalize', [AdminPenggajianController::class, 'finalize'])->name('penggajian.finalize');
        Route::patch('/penggajian/{payroll}/paid', [AdminPenggajianController::class, 'markPaid'])->name('penggajian.markPaid');

        Route::get('/pengumuman', [AdminAnnouncementController::class, 'index'])->name('pengumuman.index');
        Route::post('/pengumuman', [AdminAnnouncementController::class, 'store'])->name('pengumuman.store');
        Route::delete('/pengumuman/{announcement}', [AdminAnnouncementController::class, 'destroy'])->name('pengumuman.destroy');
    });
});

Route::prefix('karyawan')->name('karyawan.')->middleware(['auth', 'role:karyawan'])->group(function (): void {
    Route::get('/profil', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profil', [ProfileController::class, 'update'])->name('profile.update');

    Route::middleware('password.changed')->group(function (): void {
        Route::get('/dashboard', [KaryawanDashboardController::class, 'index'])->name('dashboard');

        Route::get('/absensi', [KaryawanAbsensiController::class, 'index'])->name('absensi.index');
        Route::post('/absensi', [KaryawanAbsensiController::class, 'store'])->name('absensi.store');

        Route::get('/jadwal', [KaryawanJadwalController::class, 'index'])->name('jadwal.index');
        Route::post('/jadwal/hadir', [KaryawanJadwalController::class, 'storeAttendance'])->name('jadwal.attendance.store');

        Route::get('/gaji', [KaryawanGajiController::class, 'index'])->name('gaji.index');
        Route::get('/gaji/{payroll}', [KaryawanGajiController::class, 'show'])->name('gaji.show');

        Route::get('/cuti', [KaryawanCutiController::class, 'index'])->name('cuti.index');
        Route::post('/cuti', [KaryawanCutiController::class, 'store'])->name('cuti.store');

        Route::get('/pengumuman', [KaryawanPengumumanController::class, 'index'])->name('pengumuman.index');
    });
});
