<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('employees', function (Blueprint $table) {
            $table->string('photo_path')->nullable()->after('password');
            $table->string('phone')->nullable()->after('email');
            $table->text('address')->nullable()->after('phone');
            $table->string('place_of_birth')->nullable()->after('address');
            $table->date('date_of_birth')->nullable()->after('place_of_birth');
            $table->enum('gender', ['laki_laki', 'perempuan'])->nullable()->after('date_of_birth');
            $table->string('emergency_contact_name')->nullable()->after('gender');
            $table->string('emergency_contact_phone')->nullable()->after('emergency_contact_name');
        });
    }

    public function down(): void
    {
        Schema::table('employees', function (Blueprint $table) {
            $table->dropColumn([
                'photo_path',
                'phone',
                'address',
                'place_of_birth',
                'date_of_birth',
                'gender',
                'emergency_contact_name',
                'emergency_contact_phone',
            ]);
        });
    }
};
