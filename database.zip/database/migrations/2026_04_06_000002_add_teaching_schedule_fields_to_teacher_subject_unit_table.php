<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('teacher_subject_unit', function (Blueprint $table) {
            $table->string('day_name')->nullable()->after('subject_id');
            $table->string('class_name')->nullable()->after('day_name');
            $table->time('start_time')->nullable()->after('class_name');
            $table->time('end_time')->nullable()->after('start_time');
        });
    }

    public function down(): void
    {
        Schema::table('teacher_subject_unit', function (Blueprint $table) {
            $table->dropColumn(['day_name', 'class_name', 'start_time', 'end_time']);
        });
    }
};
