<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('teacher_subject_unit', function (Blueprint $table) {
            $table->id();
            $table->foreignId('teacher_detail_id')->constrained()->cascadeOnDelete();
            $table->foreignId('unit_id')->constrained()->cascadeOnDelete();
            $table->foreignId('subject_id')->constrained()->cascadeOnDelete();
            $table->unsignedTinyInteger('hours_per_week');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('teacher_subject_unit');
    }
};
