<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('attendances', 'teacher_subject_unit_id')) {
            Schema::table('attendances', function (Blueprint $table) {
                $table->foreignId('teacher_subject_unit_id')
                    ->nullable()
                    ->after('schedule_id')
                    ->constrained('teacher_subject_unit')
                    ->cascadeOnDelete();
            });
        }

        if (! $this->indexExists('attendances', 'attendances_employee_id_index')) {
            Schema::table('attendances', function (Blueprint $table) {
                $table->index('employee_id', 'attendances_employee_id_index');
            });
        }

        if ($this->indexExists('attendances', 'attendances_employee_id_schedule_id_unique')) {
            Schema::table('attendances', function (Blueprint $table) {
                $table->dropUnique('attendances_employee_id_schedule_id_unique');
            });
        }

        if (! $this->indexExists('attendances', 'attendances_employee_schedule_session_unique')) {
            Schema::table('attendances', function (Blueprint $table) {
                $table->unique(
                    ['employee_id', 'schedule_id', 'teacher_subject_unit_id'],
                    'attendances_employee_schedule_session_unique'
                );
            });
        }
    }

    public function down(): void
    {
        if ($this->indexExists('attendances', 'attendances_employee_schedule_session_unique')) {
            Schema::table('attendances', function (Blueprint $table) {
                $table->dropUnique('attendances_employee_schedule_session_unique');
            });
        }

        if (Schema::hasColumn('attendances', 'teacher_subject_unit_id')) {
            Schema::table('attendances', function (Blueprint $table) {
                $table->dropConstrainedForeignId('teacher_subject_unit_id');
            });
        }

        if (! $this->indexExists('attendances', 'attendances_employee_id_schedule_id_unique')) {
            Schema::table('attendances', function (Blueprint $table) {
                $table->unique(['employee_id', 'schedule_id'], 'attendances_employee_id_schedule_id_unique');
            });
        }

        if ($this->indexExists('attendances', 'attendances_employee_id_index')) {
            Schema::table('attendances', function (Blueprint $table) {
                $table->dropIndex('attendances_employee_id_index');
            });
        }
    }

    private function indexExists(string $table, string $indexName): bool
    {
        $indexes = DB::select("SHOW INDEX FROM `{$table}`");

        foreach ($indexes as $index) {
            if (($index->Key_name ?? null) === $indexName) {
                return true;
            }
        }

        return false;
    }
};
