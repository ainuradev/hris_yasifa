<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('attendances', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('employee_id');
            $table->foreignId('schedule_id')->constrained()->cascadeOnDelete();
            $table->timestamp('checked_in_at')->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->enum('status', ['hadir', 'izin', 'sakit', 'alpa']);
            $table->string('notes')->nullable();
            $table->timestamps();

            $table->foreign('employee_id', 'fk_att_employee')
                ->references('id')
                ->on('employees')
                ->cascadeOnDelete();
            $table->unique(['employee_id', 'schedule_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attendances');
    }
};
