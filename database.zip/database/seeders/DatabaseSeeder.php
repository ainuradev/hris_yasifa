<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $now = now();
        $today = Carbon::today();
        $contractEndDate = $today->copy()->addYear()->format('Y-m-d');
        $payrollPeriodStart = Carbon::create($today->year, 4, 1)->startOfDay();
        $payrollPeriodEnd = $today->copy()->endOfDay();

        DB::transaction(function () use ($now, $today, $contractEndDate, $payrollPeriodStart, $payrollPeriodEnd) {
            $unitIds = $this->seedUnits($now);
            $salaryRateIds = $this->seedSalaryRates($now);
            $subjectIds = $this->seedSubjects();
            $adminPusatId = $this->seedAdmins($unitIds, $contractEndDate, $now);

            $teachers = $this->seedTeachers($unitIds, $salaryRateIds, $subjectIds, $contractEndDate, $now);

            $this->seedNonTeachers($unitIds, $salaryRateIds, $contractEndDate, $now);
            $this->seedAnnouncements($adminPusatId, $now);
            $this->seedLeaveRequests($teachers, $now);
            $this->seedEmployeeRequests($unitIds, $adminPusatId, $salaryRateIds, $now);

            $scheduleIds = $this->seedSchedules($unitIds, $payrollPeriodStart, $payrollPeriodEnd, $now);
            $this->seedTeacherAttendancesAndPayrolls(
                $teachers,
                $scheduleIds,
                $adminPusatId,
                $payrollPeriodStart,
                $payrollPeriodEnd,
                $today,
                $now
            );
        });
    }

    private function seedUnits(Carbon $now): array
    {
        $unitIds = [];

        foreach ([
            ['name' => 'MI Sirojul Falah', 'jenjang' => 'MI', 'kepala_unit' => null],
            ['name' => 'MTs Sirojul Falah', 'jenjang' => 'MTs', 'kepala_unit' => null],
            ['name' => 'MA Sirojul Falah', 'jenjang' => 'MA', 'kepala_unit' => null],
        ] as $unit) {
            $unitIds[$unit['jenjang']] = DB::table('units')->insertGetId([
                ...$unit,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }

        return $unitIds;
    }

    private function seedSalaryRates(Carbon $now): array
    {
        $salaryRateIds = [];

        foreach ([
            ['jabatan' => 'Guru', 'type' => 'guru', 'rate' => 45000.00],
            ['jabatan' => 'Guru Senior', 'type' => 'guru', 'rate' => 60000.00],
            ['jabatan' => 'Staff Admin', 'type' => 'non_guru', 'rate' => 2200000.00],
            ['jabatan' => 'Security', 'type' => 'non_guru', 'rate' => 2000000.00],
        ] as $rate) {
            $salaryRateIds[$rate['jabatan']] = DB::table('salary_rates')->insertGetId([
                ...$rate,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }

        return $salaryRateIds;
    }

    private function seedSubjects(): array
    {
        $subjectIds = [];

        foreach (['Matematika', 'IPA', 'Bahasa Indonesia'] as $subjectName) {
            $subjectIds[$subjectName] = DB::table('subjects')->insertGetId([
                'name' => $subjectName,
            ]);
        }

        return $subjectIds;
    }

    private function seedAdmins(array $unitIds, string $contractEndDate, Carbon $now): int
    {
        $adminBirthDate = '1990-01-10';
        $adminDefaultPassword = 'admin123';

        $adminPusatId = DB::table('employees')->insertGetId([
            'unit_id' => $unitIds['MI'],
            'name' => 'Admin Pusat Yayasan',
            'nik' => 'ADM000',
            'email' => 'admin-pusat@sirojulfalah.test',
            'phone' => '081234567800',
            'address' => 'Kantor Pusat Yayasan Sirojul Falah',
            'place_of_birth' => 'Bandung',
            'date_of_birth' => $adminBirthDate,
            'gender' => 'laki_laki',
            'emergency_contact_name' => 'Keluarga Admin Pusat',
            'emergency_contact_phone' => '081200000000',
            'password' => Hash::make($adminDefaultPassword),
            'must_change_password' => true,
            'type' => 'non_guru',
            'role' => 'admin_pusat',
            'status' => 'aktif',
            'contract_end_date' => $contractEndDate,
            'remember_token' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        foreach ([
            ['unit_id' => $unitIds['MI'], 'name' => 'Admin MI Sirojul Falah', 'nik' => 'ADM001', 'email' => 'admin-mi@sirojulfalah.test'],
            ['unit_id' => $unitIds['MTs'], 'name' => 'Admin MTs Sirojul Falah', 'nik' => 'ADM002', 'email' => 'admin-mts@sirojulfalah.test'],
            ['unit_id' => $unitIds['MA'], 'name' => 'Admin MA Sirojul Falah', 'nik' => 'ADM003', 'email' => 'admin-ma@sirojulfalah.test'],
        ] as $adminUnit) {
            DB::table('employees')->insert([
                'unit_id' => $adminUnit['unit_id'],
                'name' => $adminUnit['name'],
                'nik' => $adminUnit['nik'],
                'email' => $adminUnit['email'],
                'phone' => '081234567890',
                'address' => 'Jl. Yayasan Sirojul Falah No. 1',
                'place_of_birth' => 'Bandung',
                'date_of_birth' => $adminBirthDate,
                'gender' => 'laki_laki',
                'emergency_contact_name' => 'Keluarga Admin Unit',
                'emergency_contact_phone' => '081200000001',
                'password' => Hash::make($adminDefaultPassword),
                'must_change_password' => true,
                'type' => 'non_guru',
                'role' => 'admin_unit',
                'status' => 'aktif',
                'contract_end_date' => $contractEndDate,
                'remember_token' => null,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }

        return $adminPusatId;
    }

    private function seedTeachers(array $unitIds, array $salaryRateIds, array $subjectIds, string $contractEndDate, Carbon $now): array
    {
        $teachers = [];

        foreach ([
            [
                'unit_id' => $unitIds['MI'],
                'name' => 'Ahmad Fauzi',
                'nik' => 'GR001',
                'email' => 'ahmad.fauzi@sirojulfalah.test',
                'date_of_birth' => '1992-05-15',
                'gender' => 'laki_laki',
                'jabatan' => 'Guru',
                'salary_rate_id' => $salaryRateIds['Guru'],
                'attendance_exceptions' => [
                    '2026-04-14' => ['status' => 'alpa', 'notes' => 'Tidak hadir tanpa keterangan.'],
                ],
                'sessions' => [
                    ['subject' => 'Matematika', 'day_name' => 'Senin', 'class_name' => 'Kelas 4 MI', 'start_time' => '07:30:00', 'end_time' => '09:30:00', 'hours_per_week' => 2],
                    ['subject' => 'Matematika', 'day_name' => 'Selasa', 'class_name' => 'Kelas 5 MI', 'start_time' => '08:00:00', 'end_time' => '10:00:00', 'hours_per_week' => 2],
                    ['subject' => 'Matematika', 'day_name' => 'Kamis', 'class_name' => 'Kelas 6 MI', 'start_time' => '07:30:00', 'end_time' => '09:30:00', 'hours_per_week' => 2],
                ],
            ],
            [
                'unit_id' => $unitIds['MTs'],
                'name' => 'Siti Aisyah',
                'nik' => 'GR002',
                'email' => 'siti.aisyah@sirojulfalah.test',
                'date_of_birth' => '1993-11-21',
                'gender' => 'perempuan',
                'jabatan' => 'Guru Senior',
                'salary_rate_id' => $salaryRateIds['Guru Senior'],
                'attendance_exceptions' => [
                    '2026-04-08' => ['status' => 'sakit', 'notes' => 'Izin sakit dengan surat dokter.'],
                ],
                'sessions' => [
                    ['subject' => 'IPA', 'day_name' => 'Rabu', 'class_name' => 'Kelas 7 MTs', 'start_time' => '08:00:00', 'end_time' => '10:00:00', 'hours_per_week' => 2],
                    ['subject' => 'IPA', 'day_name' => 'Jumat', 'class_name' => 'Kelas 8 MTs', 'start_time' => '07:45:00', 'end_time' => '09:45:00', 'hours_per_week' => 2],
                    ['subject' => 'IPA', 'day_name' => 'Sabtu', 'class_name' => 'Kelas 9 MTs', 'start_time' => '08:15:00', 'end_time' => '10:15:00', 'hours_per_week' => 2],
                ],
            ],
            [
                'unit_id' => $unitIds['MA'],
                'name' => 'Budi Santoso',
                'nik' => 'GR003',
                'email' => 'budi.santoso@sirojulfalah.test',
                'date_of_birth' => '1991-02-03',
                'gender' => 'laki_laki',
                'jabatan' => 'Guru',
                'salary_rate_id' => $salaryRateIds['Guru'],
                'attendance_exceptions' => [],
                'sessions' => [
                    ['subject' => 'Bahasa Indonesia', 'day_name' => 'Senin', 'class_name' => 'Kelas 10 MA', 'start_time' => '09:00:00', 'end_time' => '11:00:00', 'hours_per_week' => 2],
                    ['subject' => 'Bahasa Indonesia', 'day_name' => 'Rabu', 'class_name' => 'Kelas 11 MA', 'start_time' => '09:30:00', 'end_time' => '11:30:00', 'hours_per_week' => 2],
                    ['subject' => 'Bahasa Indonesia', 'day_name' => 'Jumat', 'class_name' => 'Kelas 12 MA', 'start_time' => '08:30:00', 'end_time' => '10:30:00', 'hours_per_week' => 2],
                ],
            ],
        ] as $teacher) {
            $employeeId = DB::table('employees')->insertGetId([
                'unit_id' => $teacher['unit_id'],
                'name' => $teacher['name'],
                'nik' => $teacher['nik'],
                'email' => $teacher['email'],
                'phone' => '08123'.rand(100000, 999999),
                'address' => 'Alamat '.$teacher['name'],
                'place_of_birth' => 'Tasikmalaya',
                'date_of_birth' => $teacher['date_of_birth'],
                'gender' => $teacher['gender'],
                'emergency_contact_name' => 'Keluarga '.$teacher['name'],
                'emergency_contact_phone' => '08129'.rand(100000, 999999),
                'password' => Hash::make(Carbon::parse($teacher['date_of_birth'])->format('dmY')),
                'must_change_password' => true,
                'type' => 'guru',
                'role' => 'karyawan',
                'status' => 'aktif',
                'contract_end_date' => $contractEndDate,
                'remember_token' => null,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            $teacherDetailId = DB::table('teacher_details')->insertGetId([
                'employee_id' => $employeeId,
                'salary_rate_id' => $teacher['salary_rate_id'],
                'jabatan' => $teacher['jabatan'],
            ]);

            $sessions = [];

            foreach ($teacher['sessions'] as $session) {
                $teacherSubjectUnitId = DB::table('teacher_subject_unit')->insertGetId([
                    'teacher_detail_id' => $teacherDetailId,
                    'unit_id' => $teacher['unit_id'],
                    'subject_id' => $subjectIds[$session['subject']],
                    'day_name' => $session['day_name'],
                    'class_name' => $session['class_name'],
                    'start_time' => $session['start_time'],
                    'end_time' => $session['end_time'],
                    'hours_per_week' => $session['hours_per_week'],
                ]);

                $sessions[] = [
                    ...$session,
                    'id' => $teacherSubjectUnitId,
                ];
            }

            $teachers[] = [
                'employee_id' => $employeeId,
                'unit_id' => $teacher['unit_id'],
                'name' => $teacher['name'],
                'salary_rate' => $this->salaryRateAmount($teacher['jabatan']),
                'attendance_exceptions' => $teacher['attendance_exceptions'],
                'sessions' => $sessions,
            ];
        }

        return $teachers;
    }

    private function seedNonTeachers(array $unitIds, array $salaryRateIds, string $contractEndDate, Carbon $now): void
    {
        foreach ([
            [
                'unit_id' => $unitIds['MI'],
                'name' => 'Nisa Rahma',
                'nik' => 'NG001',
                'email' => 'nisa.rahma@sirojulfalah.test',
                'date_of_birth' => '1994-08-20',
                'gender' => 'perempuan',
                'jabatan' => 'Staff Admin',
                'salary_rate_id' => $salaryRateIds['Staff Admin'],
            ],
            [
                'unit_id' => $unitIds['MTs'],
                'name' => 'Dedi Kurniawan',
                'nik' => 'NG002',
                'email' => 'dedi.kurniawan@sirojulfalah.test',
                'date_of_birth' => '1990-12-12',
                'gender' => 'laki_laki',
                'jabatan' => 'Security',
                'salary_rate_id' => $salaryRateIds['Security'],
            ],
        ] as $nonTeacher) {
            $employeeId = DB::table('employees')->insertGetId([
                'unit_id' => $nonTeacher['unit_id'],
                'name' => $nonTeacher['name'],
                'nik' => $nonTeacher['nik'],
                'email' => $nonTeacher['email'],
                'phone' => '08121'.rand(100000, 999999),
                'address' => 'Alamat '.$nonTeacher['name'],
                'place_of_birth' => 'Garut',
                'date_of_birth' => $nonTeacher['date_of_birth'],
                'gender' => $nonTeacher['gender'],
                'emergency_contact_name' => 'Keluarga '.$nonTeacher['name'],
                'emergency_contact_phone' => '08128'.rand(100000, 999999),
                'password' => Hash::make(Carbon::parse($nonTeacher['date_of_birth'])->format('dmY')),
                'must_change_password' => true,
                'type' => 'non_guru',
                'role' => 'karyawan',
                'status' => 'aktif',
                'contract_end_date' => $contractEndDate,
                'remember_token' => null,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            DB::table('non_teacher_details')->insert([
                'employee_id' => $employeeId,
                'salary_rate_id' => $nonTeacher['salary_rate_id'],
                'jabatan' => $nonTeacher['jabatan'],
            ]);
        }
    }

    private function seedAnnouncements(int $adminPusatId, Carbon $now): void
    {
        DB::table('announcements')->insert([
            'unit_id' => null,
            'created_by' => $adminPusatId,
            'title' => 'Pengumuman Sistem HRIS',
            'content' => 'Selamat datang di sistem HRIS Yayasan Sirojul Falah. Data contoh April sudah berisi jadwal mengajar guru, absensi per sesi, dan slip gaji berdasarkan realisasi jam hadir.',
            'category' => 'umum',
            'is_global' => true,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    private function seedLeaveRequests(array $teachers, Carbon $now): void
    {
        if (empty($teachers)) return;
        
        $employeeId = $teachers[0]['employee_id']; // Use first teacher
        
        DB::table('leave_requests')->insert([
            'employee_id' => $employeeId,
            'leave_type' => 'sakit',
            'start_date' => $now->copy()->addDays(2)->format('Y-m-d'),
            'end_date' => $now->copy()->addDays(3)->format('Y-m-d'),
            'total_days' => 2,
            'reason' => 'Sakit demam berdarah, perlu istirahat.',
            'status' => 'pending',
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    private function seedEmployeeRequests(array $unitIds, int $adminPusatId, array $salaryRateIds, Carbon $now): void
    {
        DB::table('employee_requests')->insert([
            'unit_id' => $unitIds['MTs'],
            'requested_by' => $adminPusatId, // or unit admin, doesn't matter for seeding
            'name' => 'Fahmi Reza',
            'nik' => 'REQ001',
            'email' => 'fahmi.reza@sirojulfalah.test',
            'date_of_birth' => '1995-10-12',
            'type' => 'guru',
            'status' => 'pending',
            'employment_status' => 'aktif',
            'contract_end_date' => $now->copy()->addYear()->format('Y-m-d'),
            'jabatan' => 'Guru',
            'salary_rate_id' => $salaryRateIds['Guru'],
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    private function seedSchedules(array $unitIds, Carbon $periodStart, Carbon $periodEnd, Carbon $now): array
    {
        $scheduleConfigs = [
            'MI' => ['check_in_start' => '06:45:00', 'check_in_end' => '07:30:00'],
            'MTs' => ['check_in_start' => '07:00:00', 'check_in_end' => '07:45:00'],
            'MA' => ['check_in_start' => '07:15:00', 'check_in_end' => '08:00:00'],
        ];

        $scheduleIds = [];
        $dates = collect();

        for ($date = $periodStart->copy(); $date->lte($periodEnd); $date->addDay()) {
            $dates->push($date->copy());
        }

        foreach ($dates as $date) {
            $dayType = $date->dayOfWeekIso === 7 ? 'libur' : ($date->dayOfWeekIso === 6 ? 'setengah_hari' : 'normal');

            foreach ($unitIds as $jenjang => $unitId) {
                $scheduleIds[$unitId][$date->format('Y-m-d')] = DB::table('schedules')->insertGetId([
                    'unit_id' => $unitId,
                    'work_date' => $date->format('Y-m-d'),
                    'check_in_start' => $scheduleConfigs[$jenjang]['check_in_start'],
                    'check_in_end' => $scheduleConfigs[$jenjang]['check_in_end'],
                    'day_type' => $dayType,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);
            }
        }

        return $scheduleIds;
    }

    private function seedTeacherAttendancesAndPayrolls(
        array $teachers,
        array $scheduleIds,
        int $adminPusatId,
        Carbon $periodStart,
        Carbon $periodEnd,
        Carbon $today,
        Carbon $now
    ): void {
        foreach ($teachers as $teacher) {
            $monthlyHours = 0.0;
            $alpaCount = 0;

            for ($date = $periodStart->copy(); $date->lte($periodEnd); $date->addDay()) {
                $dateKey = $date->format('Y-m-d');
                $dayName = $this->indonesianDayName($date);
                $scheduleId = $scheduleIds[$teacher['unit_id']][$dateKey] ?? null;

                if (! $scheduleId || $date->dayOfWeekIso === 7) {
                    continue;
                }

                $matchingSessions = collect($teacher['sessions'])
                    ->where('day_name', $dayName)
                    ->values();

                foreach ($matchingSessions as $session) {
                    $exception = $teacher['attendance_exceptions'][$dateKey] ?? null;
                    $status = $exception['status'] ?? 'hadir';
                    $notes = $exception['notes'] ?? 'Absensi sesi mengajar otomatis dari seeder.';
                    $checkedInAt = $status === 'hadir'
                        ? Carbon::parse($dateKey.' '.$session['start_time'])->subMinutes(10)
                        : null;

                    DB::table('attendances')->insert([
                        'employee_id' => $teacher['employee_id'],
                        'schedule_id' => $scheduleId,
                        'teacher_subject_unit_id' => $session['id'],
                        'checked_in_at' => $checkedInAt,
                        'checked_out_at' => $status === 'hadir'
                            ? Carbon::parse($dateKey.' '.$session['end_time'])
                            : null,
                        'latitude' => $status === 'hadir' ? -6.9147440 : null,
                        'longitude' => $status === 'hadir' ? 107.6098100 : null,
                        'status' => $status,
                        'notes' => $notes,
                        'created_at' => $now,
                        'updated_at' => $now,
                    ]);

                    if ($status === 'hadir') {
                        $monthlyHours += $this->calculateSessionHours($session['start_time'], $session['end_time']);
                    }

                    if ($status === 'alpa') {
                        $alpaCount++;
                    }
                }
            }

            $this->seedTeacherPayroll(
                $teacher,
                $monthlyHours,
                $alpaCount,
                $adminPusatId,
                $today,
                $now
            );
        }
    }

    private function seedTeacherPayroll(
        array $teacher,
        float $monthlyHours,
        int $alpaCount,
        int $adminPusatId,
        Carbon $today,
        Carbon $now
    ): void {
        $baseSalary = $teacher['salary_rate'] * $monthlyHours;
        $absenceDeduction = $alpaCount > 0 ? ($baseSalary / 22) * $alpaCount : 0;
        $netSalary = max($baseSalary - $absenceDeduction, 0);

        $payrollId = DB::table('payrolls')->insertGetId([
            'employee_id' => $teacher['employee_id'],
            'month' => 4,
            'year' => $today->year,
            'base_salary' => round($baseSalary, 2),
            'total_allowance' => 0,
            'total_deduction' => round($absenceDeduction, 2),
            'net_salary' => round($netSalary, 2),
            'status' => 'dibayar',
            'paid_at' => $today->format('Y-m-d'),
            'created_by' => $adminPusatId,
            'updated_by' => $adminPusatId,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('payroll_details')->insert([
            'payroll_id' => $payrollId,
            'description' => sprintf(
                'Honor Mengajar Terealisasi (%s jam x Rp %s/jam)',
                rtrim(rtrim(number_format($monthlyHours, 2, '.', ''), '0'), '.'),
                number_format($teacher['salary_rate'], 0, ',', '.')
            ),
            'amount' => round($baseSalary, 2),
            'category' => 'tunjangan',
        ]);

        if ($absenceDeduction > 0) {
            DB::table('payroll_details')->insert([
                'payroll_id' => $payrollId,
                'description' => sprintf('Potongan Alpa (%d hari)', $alpaCount),
                'amount' => round($absenceDeduction, 2),
                'category' => 'potongan',
            ]);
        }

        DB::table('payroll_history')->insert([
            [
                'payroll_id' => $payrollId,
                'field_changed' => 'status',
                'old_value' => null,
                'new_value' => 'draft',
                'changed_by' => $adminPusatId,
                'changed_at' => $now->copy()->subMinutes(15),
            ],
            [
                'payroll_id' => $payrollId,
                'field_changed' => 'status',
                'old_value' => 'draft',
                'new_value' => 'final',
                'changed_by' => $adminPusatId,
                'changed_at' => $now->copy()->subMinutes(5),
            ],
            [
                'payroll_id' => $payrollId,
                'field_changed' => 'status',
                'old_value' => 'final',
                'new_value' => 'dibayar',
                'changed_by' => $adminPusatId,
                'changed_at' => $now,
            ],
        ]);
    }

    private function calculateSessionHours(string $startTime, string $endTime): float
    {
        $start = Carbon::parse($startTime);
        $end = Carbon::parse($endTime);

        return round($end->diffInMinutes($start) / 60, 2);
    }

    private function indonesianDayName(Carbon $date): string
    {
        return match ($date->dayOfWeekIso) {
            1 => 'Senin',
            2 => 'Selasa',
            3 => 'Rabu',
            4 => 'Kamis',
            5 => 'Jumat',
            6 => 'Sabtu',
            default => 'Minggu',
        };
    }

    private function salaryRateAmount(string $jabatan): float
    {
        return match ($jabatan) {
            'Guru Senior' => 60000.00,
            default => 45000.00,
        };
    }
}
